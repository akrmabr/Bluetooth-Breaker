package com.bluetoothbreaker

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

data class BtDevice(
    val key: String, val name: String, val address: String,
    val rssi: Int? = null, val bonded: Boolean = false,
    val connected: Boolean = false, val type: Int = BluetoothDevice.DEVICE_TYPE_UNKNOWN,
    val seenAt: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    private var adapter: BluetoothAdapter? = null
    private var scanner: BluetoothLeScanner? = null
    private val devices = mutableStateMapOf<String, BtDevice>()
    private var scanning by mutableStateOf(false)
    private var status by mutableStateOf("جاهز للفحص")
    private var selected by mutableStateOf<BtDevice?>(null)
    private var page by mutableStateOf("home")
    private var profileSummary by mutableStateOf("معلومات الاتصالات تعتمد على ملفات Bluetooth التي يكشفها النظام.")
    private val profileDevices = mutableStateSetOf<String>()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasBluetoothPermissions()) refreshPaired()
        else status = "يلزم السماح بصلاحيات Bluetooth لاستخدام الفحص."
    }

    private val classicReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                            else @Suppress("DEPRECATION") (intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) as? BluetoothDevice)
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt().takeIf { it != Short.MIN_VALUE }
                    if (d != null) upsert(d, rssi)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> { scanning = false; status = "انتهى البحث. الأجهزة الظاهرة ليست بالضرورة متصلة." }
            }
        }
    }

    private val leCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            result.device?.let { upsert(it, result.rssi) }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false; status = "تعذر بدء فحص BLE (رمز الخطأ $errorCode)."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter
        registerReceiver(classicReceiver, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF38D9FF), secondary = Color(0xFF647CFF),
                background = Color(0xFF07111F), surface = Color(0xFF101E30),
                onBackground = Color(0xFFEAF6FF), onSurface = Color(0xFFEAF6FF)
            )) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF07111F)) {
                    AppScreen()
                }
            }
        }
        if (!hasBluetoothPermissions()) requestBluetoothPermissions() else refreshPaired()
    }

    private fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasBluetoothPermissions() = requiredPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }
    private fun requestBluetoothPermissions() = permissionLauncher.launch(requiredPermissions())

    private fun upsert(device: BluetoothDevice, rssi: Int? = null) {
        if (!hasBluetoothPermissions()) return
        val address = try { device.address ?: "عنوان غير متاح" } catch (_: SecurityException) { "عنوان محمي" }
        val name = try { device.name?.takeIf { it.isNotBlank() } ?: "جهاز غير مسمى" } catch (_: SecurityException) { "اسم محمي" }
        val bonded = try { device.bondState == BluetoothDevice.BOND_BONDED } catch (_: SecurityException) { false }
        val type = try { device.type } catch (_: SecurityException) { BluetoothDevice.DEVICE_TYPE_UNKNOWN }
        val key = address
        val old = devices[key]
        devices[key] = BtDevice(key, name, address, rssi ?: old?.rssi, bonded, key in profileDevices, type)
    }

    private fun refreshPaired() {
        if (!hasBluetoothPermissions()) return
        try {
            adapter?.bondedDevices?.forEach { upsert(it) }
            queryProfiles()
        } catch (_: SecurityException) { status = "صلاحية قراءة الأجهزة المقترنة غير متاحة." }
    }

    @Suppress("DEPRECATION")
    private fun queryProfiles() {
        val a = adapter ?: return
        val profiles = listOf(BluetoothProfile.A2DP, BluetoothProfile.HEADSET)
        profiles.forEach { profile ->
            try {
                a.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profileType: Int, proxy: BluetoothProfile) {
                        try {
                            proxy.connectedDevices.forEach { d ->
                                val address = d.address
                                profileDevices.add(address)
                                upsert(d)
                            }
                            profileSummary = "تم فحص ملفات الصوت المتاحة. النتيجة تخص اتصالات هذا الهاتف فقط."
                        } catch (_: SecurityException) { profileSummary = "تعذر قراءة حالة ملفات Bluetooth بسبب الصلاحيات." }
                        try { a.closeProfileProxy(profileType, proxy) } catch (_: Exception) {}
                    }
                    override fun onServiceDisconnected(profileType: Int) {}
                }, profile)
            } catch (_: Exception) { profileSummary = "بعض ملفات الاتصال غير متاحة على هذا الجهاز." }
        }
    }

    private fun startScan() {
        if (!hasBluetoothPermissions()) { requestBluetoothPermissions(); return }
        val a = adapter
        if (a == null) { status = "هذا الهاتف لا يوفر Bluetooth."; return }
        if (!a.isEnabled) { status = "فعّل Bluetooth من إعدادات الهاتف أولاً."; return }
        stopScan()
        devices.values.toList().forEach { if (!it.bonded) devices.remove(it.key) }
        scanning = true; status = "جارٍ البحث عن الأجهزة القريبة..."
        try {
            scanner = a.bluetoothLeScanner
            scanner?.startScan(leCallback)
        } catch (_: SecurityException) { status = "لا توجد صلاحية لفحص BLE."; scanning = false }
        try {
            if (a.startDiscovery()) status = "جارٍ فحص Bluetooth Classic و BLE..."
            else if (scanner == null) { status = "تعذر بدء البحث. جرّب مجدداً."; scanning = false }
        } catch (_: SecurityException) { status = "لا توجد صلاحية لفحص Bluetooth."; scanning = false }
    }

    private fun stopScan() {
        try { scanner?.stopScan(leCallback) } catch (_: Exception) {}
        try { if (adapter?.isDiscovering == true) adapter?.cancelDiscovery() } catch (_: Exception) {}
        scanning = false
    }

    private fun openBluetoothSettings() {
        startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    override fun onDestroy() {
        stopScan()
        try { unregisterReceiver(classicReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Composable
    private fun AppScreen() {
        Column(Modifier.fillMaxSize().background(Color(0xFF07111F)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF12334A)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Bluetooth, null, tint = Color(0xFF38D9FF), modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("BLUETOOTH BREAKER", fontWeight = FontWeight.Black, color = Color.White, fontSize = 18.sp)
                    Text("Device & connection manager", color = Color(0xFF91AFC4), fontSize = 11.sp)
                }
                IconButton(onClick = { openBluetoothSettings() }) { Icon(Icons.Default.SettingsBluetooth, "إعدادات Bluetooth", tint = Color(0xFF38D9FF)) }
            }
            Spacer(Modifier.height(18.dp))
            when (page) {
                "home" -> Dashboard()
                "scan" -> ScannerPage()
                "paired" -> PairedPage()
                "recovery" -> RecoveryPage()
                "details" -> DeviceDetails()
            }
            Spacer(Modifier.weight(1f))
            NavigationBar(containerColor = Color(0xFF101E30), contentColor = Color(0xFF38D9FF)) {
                NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(selected = page == "scan", onClick = { page = "scan" }, icon = { Icon(Icons.Default.Radar, null) }, label = { Text("الفحص") })
                NavigationBarItem(selected = page == "paired", onClick = { refreshPaired(); page = "paired" }, icon = { Icon(Icons.Default.Devices, null) }, label = { Text("المقترنة") })
                NavigationBarItem(selected = page == "recovery", onClick = { page = "recovery" }, icon = { Icon(Icons.Default.RestartAlt, null) }, label = { Text("استعادة") })
            }
        }
    }

    @Composable
    private fun Dashboard() {
        val enabled = try { adapter?.isEnabled == true } catch (_: Exception) { false }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF10243A)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(if (enabled) Color(0xFF4BE3B1) else Color(0xFFFFB454)))
                    Spacer(Modifier.width(8.dp))
                    Text(if (enabled) "Bluetooth مفعّل" else "Bluetooth غير مفعّل", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                Text("اكتشف أجهزتك القريبة", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("افحص الأجهزة ثم راجع حالة الاقتران والاتصال المتاحة.", color = Color(0xFFAAC0D2), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { page = "scan"; startScan() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Radar, null); Spacer(Modifier.width(8.dp)); Text("ابدأ الفحص", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { openBluetoothSettings() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("فتح إعدادات Bluetooth") }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("الأجهزة المكتشفة", devices.size.toString(), Modifier.weight(1f))
            StatCard("المقترنة", devices.values.count { it.bonded }.toString(), Modifier.weight(1f))
            StatCard("متصلة بهذا الهاتف", devices.values.count { it.connected }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Text("آخر الأجهزة", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(profileSummary, color = Color(0xFF8FAFC5), fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        DeviceList(devices.values.sortedByDescending { it.seenAt }.take(4))
        Spacer(Modifier.height(8.dp))
        Text("تنبيه: التطبيق لا يستطيع معرفة الهاتف الآخر المتصل بسماعتك أو إجباره على قطع الاتصال. الأجهزة القريبة ليست بالضرورة متصلة.", color = Color(0xFFFFC477), fontSize = 12.sp)
    }

    @Composable
    private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
        Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF101E30)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(12.dp)) { Text(value, color = Color(0xFF38D9FF), fontSize = 23.sp, fontWeight = FontWeight.Bold); Text(label, color = Color(0xFF9CB5C8), fontSize = 10.sp) }
        }
    }

    @Composable
    private fun ScannerPage() {
        Column {
            Text("فحص الأجهزة القريبة", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(status, color = Color(0xFF9CB5C8), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { startScan() }, modifier = Modifier.weight(1f)) { Text("فحص") }
                OutlinedButton(onClick = { stopScan(); status = "تم إيقاف الفحص." }, modifier = Modifier.weight(1f)) { Text("إيقاف") }
            }
            Spacer(Modifier.height(12.dp))
            DeviceList(devices.values.sortedByDescending { it.rssi ?: -999 })
        }
    }

    @Composable
    private fun PairedPage() {
        Column {
            Text("الأجهزة المقترنة", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("هذه قائمة الأجهزة المقترنة بهذا الهاتف فقط.", color = Color(0xFF9CB5C8), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { refreshPaired() }) { Text("تحديث القائمة") }
            DeviceList(devices.values.filter { it.bonded })
        }
    }

    @Composable
    private fun RecoveryPage() {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("استعادة السماعة", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("خطوات آمنة لاستعادة الاقتران مع هاتفك.", color = Color(0xFF9CB5C8))
            Spacer(Modifier.height(14.dp))
            RecoveryStep("1", "اشحن السماعة", "تأكد أن بطارية السماعة كافية قبل بدء العملية.")
            RecoveryStep("2", "أوقف الاتصال السابق إن أمكن", "إذا كانت السماعة تتصل تلقائياً بجهاز آخر، أوقف Bluetooth في ذلك الجهاز إن كان متاحاً لك.")
            RecoveryStep("3", "أدخل السماعة وضع الاقتران أو إعادة الضبط", "طريقة الضغط تختلف حسب الماركة والموديل. لا توجد مجموعة أزرار موحدة لكل السماعات.")
            RecoveryStep("4", "امسح الاقتران القديم من هاتفك", "من إعدادات Bluetooth في هاتفك، اختر السماعة ثم إلغاء الاقتران إذا كانت محفوظة.")
            RecoveryStep("5", "اربط السماعة بهاتفك", "فعّل وضع الاقتران، ثم افتح إعدادات Bluetooth واختر اسم السماعة.")
            Button(onClick = { openBluetoothSettings() }, modifier = Modifier.fillMaxWidth()) { Text("فتح إعدادات Bluetooth") }
            Text("ملاحظة: إعادة ضبط السماعة تمسح ذاكرتها فقط إذا كانت تدعم ذلك؛ ولا تمسح سجل الاقتران من الهاتف الآخر. لا يمكن لهذا التطبيق فصل هاتف بعيد.", color = Color(0xFFFFC477), fontSize = 12.sp)
        }
    }

    @Composable
    private fun RecoveryStep(number: String, title: String, detail: String) {
        Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101E30))) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0xFF123D55)), contentAlignment = Alignment.Center) { Text(number, color = Color(0xFF38D9FF), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Column { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(detail, color = Color(0xFF9CB5C8), fontSize = 12.sp) }
            }
        }
    }

    @Composable
    private fun DeviceDetails() {
        val d = selected ?: return
        Column {
            Text(d.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("العنوان: ${d.address}", color = Color(0xFF9CB5C8), fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            DetailLine("الاقتران بهذا الهاتف", if (d.bonded) "مقترن" else "غير مقترن")
            DetailLine("الاتصال بهذا الهاتف", if (d.connected) "متصل عبر ملف صوت مدعوم" else "غير مثبت / غير متصل بهذا الهاتف")
            DetailLine("قوة الإشارة", d.rssi?.let { "$it dBm" } ?: "غير متاحة")
            DetailLine("نوع الجهاز", when (d.type) { BluetoothDevice.DEVICE_TYPE_CLASSIC -> "Classic"; BluetoothDevice.DEVICE_TYPE_LE -> "BLE"; BluetoothDevice.DEVICE_TYPE_DUAL -> "Dual"; else -> "غير معروف" })
            DetailLine("آخر ظهور", DateFormat.getTimeInstance().format(Date(d.seenAt)))
            Spacer(Modifier.height(14.dp))
            Button(onClick = { openBluetoothSettings() }, modifier = Modifier.fillMaxWidth()) { Text("إدارة الاتصال من إعدادات النظام") }
            OutlinedButton(onClick = { page = "recovery" }, modifier = Modifier.fillMaxWidth()) { Text("فتح إرشادات استعادة السماعة") }
        }
    }

    @Composable
    private fun DetailLine(label: String, value: String) {
        Card(Modifier.fillMaxWidth().padding(bottom = 7.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101E30))) {
            Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, color = Color(0xFF9CB5C8), fontSize = 12.sp)
                Text(value, color = Color.White, fontSize = 12.sp)
            }
        }
    }

    @Composable
    private fun DeviceList(list: List<BtDevice>) {
        if (list.isEmpty()) {
            Text("لا توجد أجهزة لعرضها حالياً. ابدأ الفحص أو حدّث قائمة الاقتران.", color = Color(0xFF8FAFC5), fontSize = 12.sp, modifier = Modifier.padding(12.dp))
        } else {
            LazyColumn(Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.key }) { d ->
                    Card(Modifier.fillMaxWidth().clickable { selected = d; page = "details" }, colors = CardDefaults.cardColors(containerColor = Color(0xFF101E30)), shape = RoundedCornerShape(15.dp)) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Headphones, null, tint = Color(0xFF38D9FF), modifier = Modifier.size(27.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(d.address, color = Color(0xFF819EB4), fontSize = 10.sp)
                                Text(buildString {
                                    append(if (d.bonded) "مقترن بهذا الهاتف" else "غير مقترن")
                                    append(" • ")
                                    append(if (d.connected) "متصل بهذا الهاتف" else "الاتصال غير مثبت")
                                    d.rssi?.let { append(" • $it dBm") }
                                }, color = Color(0xFF38D9FF), fontSize = 10.sp)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF819EB4))
                        }
                    }
                }
            }
        }
    }
}
