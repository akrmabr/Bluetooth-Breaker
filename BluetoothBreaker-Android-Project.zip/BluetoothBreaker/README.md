# Bluetooth Breaker

Native Android Kotlin + Jetpack Compose starter project for Infinix Smart 8 / Android 13.

## What works in this project
- Runtime Bluetooth permissions (Android 12+ and legacy location permission for older Android).
- Bluetooth Classic discovery and BLE scan.
- Paired-device listing.
- A2DP and HEADSET profile connection enumeration for **this phone**, where the OS exposes it.
- Device details, Bluetooth settings shortcut, and generic headset recovery guide.
- Honest status labels: nearby/discoverable does not mean connected.

## Important Android limitation
An ordinary Android app cannot identify the unrelated phone currently connected to a headset, nor remotely disconnect that phone. The app does not use hidden APIs, reflection, jamming, or fake disconnect actions. Clearing a headset's remembered pairings is model-specific and must use the manufacturer's reset procedure.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Use JDK 17.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install `app/build/outputs/apk/debug/app-debug.apk` on the phone.

## Notes
- This workspace did not include Android SDK or Gradle, so an APK has not been compiled or device-tested here.
- Some OEM Android builds may restrict profile status information.
